import type { GovernorRace } from './types';
import { STATE_NAMES, PREVIOUS_GCB_R_MARGIN } from './stateGrid';
import { RATING_R_PROB, ratingFromRProb } from './ratings';
import { STATE_STRENGTH, UNPOLLED_ENV_WEIGHT, clampStrength, marginForRProb, winProbR } from './raceProb';
import { applyEnvironmentShiftMargin } from '../environmentShift';

// Same convention as senateData.ts: real 2026 field, a bootstrap-prior `rating` that computeGovernorRaces() below
// overrides with a real-data-derived one whenever live polling, a hand-researched snapshot, or the environment shift
// gives it something better to go on.
const RAW: Omit<GovernorRace, 'id' | 'stateName'>[] = [
  { stateAbbr: 'AL', incumbentParty: 'R', incumbentName: null, open: true, rating: 'SafeR' },
  { stateAbbr: 'AK', incumbentParty: 'R', incumbentName: null, open: true, rating: 'LikelyR' },
  { stateAbbr: 'AZ', incumbentParty: 'D', incumbentName: 'Katie Hobbs', open: false, rating: 'LeanD' },
  { stateAbbr: 'AR', incumbentParty: 'R', incumbentName: 'Sarah Huckabee Sanders', open: false, rating: 'SafeR' },
  { stateAbbr: 'CA', incumbentParty: 'D', incumbentName: null, open: true, rating: 'SafeD' },
  { stateAbbr: 'CO', incumbentParty: 'D', incumbentName: null, open: true, rating: 'LikelyD' },
  { stateAbbr: 'CT', incumbentParty: 'D', incumbentName: 'Ned Lamont', open: false, rating: 'SafeD' },
  { stateAbbr: 'FL', incumbentParty: 'R', incumbentName: null, open: true, rating: 'LikelyR' },
  { stateAbbr: 'GA', incumbentParty: 'R', incumbentName: null, open: true, rating: 'Tossup' },
  { stateAbbr: 'HI', incumbentParty: 'D', incumbentName: 'Josh Green', open: false, rating: 'SafeD' },
  { stateAbbr: 'ID', incumbentParty: 'R', incumbentName: 'Brad Little', open: false, rating: 'SafeR' },
  { stateAbbr: 'IL', incumbentParty: 'D', incumbentName: 'JB Pritzker', open: false, rating: 'SafeD' },
  { stateAbbr: 'IA', incumbentParty: 'R', incumbentName: null, open: true, rating: 'LikelyR' },
  { stateAbbr: 'KS', incumbentParty: 'D', incumbentName: null, open: true, rating: 'LeanR' },
  { stateAbbr: 'ME', incumbentParty: 'D', incumbentName: null, open: true, rating: 'LeanD' },
  { stateAbbr: 'MD', incumbentParty: 'D', incumbentName: 'Wes Moore', open: false, rating: 'SafeD' },
  { stateAbbr: 'MA', incumbentParty: 'D', incumbentName: 'Maura Healey', open: false, rating: 'SafeD' },
  { stateAbbr: 'MI', incumbentParty: 'D', incumbentName: null, open: true, rating: 'Tossup',
    demCandidate: 'Jocelyn Benson', repCandidate: 'John James' },
  { stateAbbr: 'MN', incumbentParty: 'D', incumbentName: null, open: true, rating: 'LeanD' },
  { stateAbbr: 'NE', incumbentParty: 'R', incumbentName: 'Jim Pillen', open: false, rating: 'SafeR' },
  { stateAbbr: 'NV', incumbentParty: 'R', incumbentName: 'Joe Lombardo', open: false, rating: 'LeanR' },
  { stateAbbr: 'NH', incumbentParty: 'R', incumbentName: 'Kelly Ayotte', open: false, rating: 'LikelyR' },
  { stateAbbr: 'NM', incumbentParty: 'D', incumbentName: null, open: true, rating: 'LikelyD' },
  { stateAbbr: 'NY', incumbentParty: 'D', incumbentName: 'Kathy Hochul', open: false, rating: 'LikelyD' },
  { stateAbbr: 'OH', incumbentParty: 'R', incumbentName: null, open: true, rating: 'LikelyR' },
  { stateAbbr: 'OK', incumbentParty: 'R', incumbentName: null, open: true, rating: 'SafeR' },
  { stateAbbr: 'OR', incumbentParty: 'D', incumbentName: 'Tina Kotek', open: false, rating: 'LikelyD' },
  { stateAbbr: 'PA', incumbentParty: 'D', incumbentName: 'Josh Shapiro', open: false, rating: 'LikelyD' },
  { stateAbbr: 'RI', incumbentParty: 'D', incumbentName: 'Dan McKee', open: false, rating: 'SafeD' },
  { stateAbbr: 'SC', incumbentParty: 'R', incumbentName: null, open: true, rating: 'SafeR' },
  { stateAbbr: 'SD', incumbentParty: 'R', incumbentName: 'Larry Rhoden', open: false, rating: 'SafeR' },
  { stateAbbr: 'TN', incumbentParty: 'R', incumbentName: null, open: true, rating: 'SafeR' },
  { stateAbbr: 'TX', incumbentParty: 'R', incumbentName: 'Greg Abbott', open: false, rating: 'SafeR' },
  { stateAbbr: 'VT', incumbentParty: 'R', incumbentName: 'Phil Scott', open: false, rating: 'SafeR' },
  { stateAbbr: 'WI', incumbentParty: 'D', incumbentName: null, open: true, rating: 'Tossup' },
  { stateAbbr: 'WY', incumbentParty: 'R', incumbentName: null, open: true, rating: 'SafeR' },
];

export const GOVERNOR_RACES: GovernorRace[] = RAW.map((r) => ({
  ...r,
  id: `gov-${r.stateAbbr.toLowerCase()}`,
  stateName: STATE_NAMES[r.stateAbbr],
}));

/** Same idea as computeSenateRaces — individually polled, so a lighter weight. */
export function computeGovernorRaces(
  currentGcbRMargin: number,
  weight = UNPOLLED_ENV_WEIGHT,
  liveMargins: Record<string, number> = {},
  liveStrengths: Record<string, number> = {}
): GovernorRace[] {
  return GOVERNOR_RACES.map((r) => {
    const realBaseline = liveMargins[r.id] ?? r.pollMargin ?? undefined;
    const ownMargin = realBaseline ?? marginForRProb(RATING_R_PROB[r.rating], STATE_STRENGTH);
    const effectiveWeight = realBaseline !== undefined ? Math.min(weight, 0.1) : weight;
    const shifted = applyEnvironmentShiftMargin(ownMargin, PREVIOUS_GCB_R_MARGIN, currentGcbRMargin, effectiveWeight);
    // A race with a real poll average is as sure as ProbCalc's own alphas for those polls say (bounded — see raceProb.ts);
    // everything else gets the fixed prior strength.
    const strength = liveStrengths[r.id] !== undefined ? clampStrength(liveStrengths[r.id]) : STATE_STRENGTH;
    const pR = winProbR(shifted, strength);
    return { ...r, rating: ratingFromRProb(pR), computedMargin: shifted, pR, strength };
  });
}
